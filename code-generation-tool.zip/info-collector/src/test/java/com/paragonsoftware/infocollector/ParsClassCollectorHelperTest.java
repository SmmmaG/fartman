package com.paragonsoftware.infocollector;

public class ParsClassCollectorHelperTest {
}
