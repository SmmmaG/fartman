package com.paragonsoftware.test.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

/**
 * OverloadedTestRestController remark
 */
@RestController
@RequestMapping("/test/overload")
public class OverloadedTestRestController {
    /**
     *
     */
    @RequestMapping(value = "/simpleget1", method = RequestMapping.GET)
    public String overMethodSimple(@RequestParam String id) {
        // TODO: to ba do doo doo
        return "";
    }

    @GetMapping(value = "/simpleget2")
    public String overMethodSimple(@RequestParam String id, @RequestParam String thisId) {
        // TODO: to ba do doo doo
        return "";
    }

    @GetMapping("/simpleget3")
    public String overMethodSimple(@RequestParam String id, @RequestParam UUID thisId) {
        // TODO: to ba do doo doo
        return "";
    }

    @GetMapping(value = "/simpleget4")
    public boolean overMethodSimple(@RequestParam String id, @RequestBody com.paragonsoftware.test.rest.dto.dto.DtoSimple dto) {
        // TODO: to ba do doo doo
        return true;
    }

    @GetMapping(value = "/simpleget4")
    public boolean overMethodSimple(@RequestParam String id, @RequestBody com.paragonsoftware.test.rest.dto.DtoSimple dto) {
        // TODO: to ba do doo doo
        return true;
    }
}