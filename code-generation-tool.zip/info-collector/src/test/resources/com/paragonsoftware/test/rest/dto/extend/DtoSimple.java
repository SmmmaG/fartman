package com.paragonsoftware.test.rest.dto.extend;

/**
 * com.paragonsoftware.test.rest.dto.extend.DtoSimple remark
 */
public class DtoSimple{
    private String name;
    private String value;

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setValue(String value) {
        this.value = value;
    }
}