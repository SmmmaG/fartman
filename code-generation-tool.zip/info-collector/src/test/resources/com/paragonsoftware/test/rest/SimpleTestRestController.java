package com.paragonsoftware.test.rest;

import org.springframework.web.bind.annotation.*;
/**
 * SimpleTestRestController remark
 */
@RestController
@RequestMapping("/test/simple")
public class SimpleTestRestController {
    @RequestMapping ( value = "/simpleget", method = RequestMapping.GET)
    public String simpleMethodGet(@RequestParam String id) {
        // TODO: to ba do doo doo
        return "";
    }

    @RequestMapping (value = "/simplepost", method = RequestMapping.POST)
    public void simpleMethodPost(@RequestParam String id) {
        // TODO: to ba do doo doo
    }
}