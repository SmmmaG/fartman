package com.paragonsoftware.test.rest;

import org.springframework.web.bind.annotation.*;

/**
 * SimpleTestRestController remark
 */
@RestController
@RequestMapping("/test/extend")
public class ExtendedAnnotationsTestRestController {

    @RequestMapping(value = "/simpleget", method = RequestMapping.GET)
    public String extendMethodSimpleGet(@RequestParam String id) {
        // TODO: to ba do doo doo
        return "";
    }

    @GetMapping("/get")
    public String extendMethodGet(@RequestParam String id) {
        // TODO: to ba do doo doo
        return "";
    }

    @RequestMapping(value = "/simplepost", method = RequestMapping.POST)
    public void extendMethodSimplePost(@RequestParam String id) {
        // TODO: to ba do doo doo
    }

    @PostMapping("/post")
    public void extendMethodPost(@RequestBody String id) {
        // TODO: to ba do doo doo
    }
}