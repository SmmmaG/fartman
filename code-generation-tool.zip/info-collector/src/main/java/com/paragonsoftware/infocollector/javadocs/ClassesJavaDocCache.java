package com.paragonsoftware.infocollector.javadocs;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.RootDoc;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Classes description wrapper
 */
public class ClassesJavaDocCache {
	/**
	 * cashed description of classes
	 * key - class full name
	 * value - class javaDoc or other description
	 */
	private static final Map<String, String> classDescriptionsMap = new ConcurrentHashMap<>();

	private ClassesJavaDocCache() {
	}

	/**
	 * @param doc
	 */
	public static synchronized void initCache(RootDoc doc) {
		if (classDescriptionsMap.isEmpty()) {
			for (ClassDoc classDoc : doc.classes()) {
				classDescriptionsMap.put(classDoc.qualifiedName(), classDoc.getRawCommentText());
			}
		}
	}

	/**
	 * @param className
	 * @param description
	 */
	public static synchronized void add(String className, String description) {
		if (classDescriptionsMap.isEmpty() || (!classDescriptionsMap.containsKey(className))) {
			classDescriptionsMap.put(className, description);
		}
	}

	public static String getClassDescription(String className) {
		if ((!classDescriptionsMap.isEmpty()) && classDescriptionsMap.containsKey(className)) {
			return classDescriptionsMap.get(className);
		}
		return "";
	}


}
