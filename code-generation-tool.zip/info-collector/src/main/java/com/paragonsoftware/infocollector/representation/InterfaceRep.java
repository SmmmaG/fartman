package com.paragonsoftware.infocollector.representation;

import com.sun.javadoc.ClassDoc;

import java.util.List;

public class InterfaceRep implements DocInfo<ClassDoc> {

	private ServiceRep serviceRep;
	private List<MethodRep> methods;
	private ClassDoc classDoc;

	protected InterfaceRep() {
	}

	public static InterfaceRep createInstance() {
		return new InterfaceRep();
	}

	public static InterfaceRep createInstance(ServiceRep serviceRep) {
		InterfaceRep rep = createInstance();
		rep.setServiceRep(serviceRep);
		return rep;
	}

	public static InterfaceRep createInstance(ServiceRep serviceRep, List<MethodRep> methods) {
		InterfaceRep rep = createInstance(serviceRep);
		rep.setMethods(methods);
		return rep;
	}

	public ServiceRep getServiceRep() {
		return serviceRep;
	}

	public void setServiceRep(ServiceRep serviceRep) {
		this.serviceRep = serviceRep;
	}

	public List<MethodRep> getMethods() {
		return methods;
	}

	public void setMethods(List<MethodRep> methods) {
		this.methods = methods;
	}


	@Override
	public ClassDoc getDocRepresentation() {
		return classDoc;
	}

	@Override
	public void setDocRepresentation(ClassDoc doc) {
		classDoc = doc;

	}
}
