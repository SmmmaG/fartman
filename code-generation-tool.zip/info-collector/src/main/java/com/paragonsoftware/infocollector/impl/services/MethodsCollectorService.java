package com.paragonsoftware.infocollector.impl.services;

import com.paragonsoftware.infocollector.ServiceCollectorService;
import com.paragonsoftware.infocollector.representation.MethodRep;
import com.paragonsoftware.infocollector.representation.ParamRep;
import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.MethodDoc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

public class MethodsCollectorService implements ServiceCollectorService<MethodRep, ClassDoc> {
	@Override
	public void collect(final Collection<MethodRep> docInfos, final ClassDoc doc) {
		Stream<MethodDoc> stream = Stream.of(doc.methods());
		stream.filter(methodDoc -> (!methodDoc.isPrivate())).forEach(methodDoc -> {
			MethodRep rep = MethodRep.createInstance(methodDoc.name(), methodDoc.commentText());

			rep.setDocRepresentation(methodDoc);

			List<ParamRep> params = new ArrayList<>();
			ParametersCollectorService parametersCollectorService = new ParametersCollectorService();
			parametersCollectorService.collect(params, methodDoc);
			rep.setParamList(params);

			docInfos.add(rep);
		});
	}
}
