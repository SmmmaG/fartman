package com.paragonsoftware.infocollector.impl.services;

import com.paragonsoftware.infocollector.ServiceCollectorService;
import com.paragonsoftware.infocollector.representation.ParamRep;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.ParamTag;
import com.sun.javadoc.Parameter;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

public class ParametersCollectorService implements ServiceCollectorService<ParamRep, MethodDoc> {
	@Override
	public void collect(final Collection<ParamRep> resultList, final MethodDoc parentStruct) {
		Stream<ParamTag> streamTags = Stream.of(parentStruct.paramTags());
		Map<String, String> paramsDesc = new HashMap<>();
		streamTags.forEach(paramTag -> paramsDesc.put(paramTag.parameterName(), paramTag.parameterComment()));
		Stream<Parameter> stream = Stream.of(parentStruct.parameters());
		stream.forEach(param -> {
			ParamRep rep = new ParamRep();
			rep.setName(param.name());
			rep.setDocRepresentation(param);
			String description = paramsDesc.containsKey(param.name()) ? paramsDesc.get(param.name()) : "";
			rep.setDescription(description);
			rep.setObjectReference(param.type().isPrimitive() ? param.typeName() : param.type().qualifiedTypeName());
		});
	}
}
