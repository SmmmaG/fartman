package com.paragonsoftware.infocollector.representation;

public interface DocInfo<C extends Object> {

	C getDocRepresentation();

	void setDocRepresentation(C doc);

}
