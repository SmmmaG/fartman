package com.paragonsoftware.infocollector.representation;

import com.sun.javadoc.Parameter;

public class ParamRep implements DocInfo<Parameter> {

	private String name;
	private String description;
	private String objectReference;
	private Parameter doc;

	public String getObjectReference() {
		return objectReference;
	}

	public void setObjectReference(String objectReference) {
		this.objectReference = objectReference;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public Parameter getDocRepresentation() {
		return doc;
	}


	@Override
	public void setDocRepresentation(Parameter doc) {
		this.doc = doc;
	}
}
