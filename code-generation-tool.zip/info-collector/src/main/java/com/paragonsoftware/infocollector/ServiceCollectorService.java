package com.paragonsoftware.infocollector;


import com.paragonsoftware.infocollector.representation.DocInfo;
import com.sun.javadoc.Doc;

import java.util.Collection;

/**
 * @param <R>
 * @param <D>
 */
public interface ServiceCollectorService<R extends DocInfo, D extends Doc> {
	/**
	 * @param resultList
	 * @param parentStruct
	 */
	void collect(final Collection<R> resultList, final D parentStruct);
}
