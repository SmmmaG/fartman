package com.paragonsoftware.infocollector.representation;


import com.sun.javadoc.ClassDoc;

public class ServiceRep implements DocInfo<ClassDoc> {
	private String name;
	private String description;
	private ClassDoc doc;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public ClassDoc getDocRepresentation() {
		return doc;
	}

	@Override
	public void setDocRepresentation(ClassDoc doc) {
		this.doc = doc;
	}
}
