package com.paragonsoftware.infocollector.representation;


import java.util.List;

/**
 *
 */
public class ClassRep extends InterfaceRep {
	private InterfaceRep interfaceRep;

	protected ClassRep() {
		super();
	}

	public static ClassRep createInstance(InterfaceRep interfaceRep, List<MethodRep> methodsList) {
		ClassRep rep = createInstance(interfaceRep);
		rep.setMethods(methodsList);
		return rep;
	}

	public static ClassRep createInstance(InterfaceRep interfaceRep) {
		ClassRep rep = createInstance();
		rep.setInterfaceRep(interfaceRep);
		return rep;
	}

	public static ClassRep createInstance() {
		ClassRep rep = new ClassRep();
		return rep;
	}

	public InterfaceRep getInterfaceRep() {
		return interfaceRep;
	}

	public void setInterfaceRep(InterfaceRep interfaceRep) {
		this.interfaceRep = interfaceRep;
	}


}
