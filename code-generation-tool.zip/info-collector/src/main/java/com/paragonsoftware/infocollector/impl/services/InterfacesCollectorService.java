package com.paragonsoftware.infocollector.impl.services;

import com.paragonsoftware.infocollector.ServiceCollectorService;
import com.paragonsoftware.infocollector.representation.InterfaceRep;
import com.paragonsoftware.infocollector.representation.MethodRep;
import com.paragonsoftware.infocollector.representation.ServiceRep;
import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.RootDoc;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;

/**
 *
 */
public class InterfacesCollectorService implements ServiceCollectorService<InterfaceRep, RootDoc> {
	@Override
	public void collect(final Collection<InterfaceRep> docInfos, final RootDoc doc) {
		Stream<ClassDoc> stream = Stream.of(doc.classes());
		stream.filter(classDoc -> classDoc.isInterface() && classDoc.name().endsWith("Service")).forEach(classDoc -> {
			ServiceRep service = new ServiceRep();
			service.setName(classDoc.name());
			service.setDescription(classDoc.commentText());
			InterfaceRep rep = InterfaceRep.createInstance(service);

			List<MethodRep> methods = new LinkedList<>();
			MethodsCollectorService methodsCollector = new MethodsCollectorService();
			methodsCollector.collect(methods, classDoc);
			rep.setMethods(methods);

			docInfos.add(rep);
		});
	}
}
