package com.paragonsoftware.infocollector;

import com.paragonsoftware.infocollector.representation.ClassRep;
import com.paragonsoftware.infocollector.representation.DocInfo;
import com.paragonsoftware.infocollector.representation.InterfaceRep;
import com.sun.javadoc.Doc;

import java.util.Collection;
import java.util.Stack;

/**
 * @param <C>
 * @param <R>
 */
public interface ImplemetationCollectorService<C extends DocInfo, R extends Doc> extends ServiceCollectorService<C, R> {
	/**
	 * @param classesImplStack
	 * @param interfaceRep
	 * @param classes
	 */
	void collectImplementation(final Stack<ClassRep> classesImplStack, final InterfaceRep interfaceRep, final Collection<ClassRep> classes);
}
