package com.paragonsoftware.infocollector.impl.services;

import com.paragonsoftware.infocollector.ImplemetationCollectorService;
import com.paragonsoftware.infocollector.representation.ClassRep;
import com.paragonsoftware.infocollector.representation.InterfaceRep;
import com.paragonsoftware.infocollector.representation.MethodRep;
import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.RootDoc;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.stream.Stream;

public class ImplementaionClassesCollectorService implements ImplemetationCollectorService<ClassRep, RootDoc> {
	@Override
	public void collect(final Collection<ClassRep> resultList, final RootDoc parentStruct) {
		Stream<ClassDoc> stream = Stream.of(parentStruct.classes());
		stream.filter(classDoc -> (!classDoc.isInterface())).forEach(classDoc -> {
			ClassRep classRep = ClassRep.createInstance();
			classRep.setDocRepresentation(classDoc);

			List<MethodRep> methods = new LinkedList<>();
			MethodsCollectorService methodsCollector = new MethodsCollectorService();
			methodsCollector.collect(methods, classDoc);
			classRep.setMethods(methods);

			resultList.add(classRep);
		});
	}

	@Override
	public void collectImplementation(final Stack<ClassRep> classesImplStack, final InterfaceRep interfaceRep,
									  final Collection<ClassRep> classes) {
		if (interfaceRep != null && classes != null && (!classes.isEmpty())) {
			classes.stream().filter(classRep ->
					(classRep.getInterfaceRep() != null && classRep.getInterfaceRep().equals(interfaceRep))
							|| classRep.getDocRepresentation().subclassOf(interfaceRep.getDocRepresentation())).sorted((o1, o2) -> {
				if (o1.equals(o2)) {
					return 0;
				} else if (o1.getDocRepresentation().subclassOf(o2.getDocRepresentation())) {
					return -1;
				}
				return 1;
			}).forEachOrdered(classRep -> classesImplStack.add(classRep));
		}
	}
}
