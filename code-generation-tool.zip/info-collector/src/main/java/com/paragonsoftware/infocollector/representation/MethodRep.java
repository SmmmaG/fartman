package com.paragonsoftware.infocollector.representation;

import com.sun.javadoc.MethodDoc;

import java.util.List;

public class MethodRep implements DocInfo<MethodDoc> {

	private String name;
	private String description;
	private ClassRep impl = null;
	private List<ParamRep> paramList = null;
	private MethodDoc methodDefenition = null;

	private MethodRep() {

	}

	public static MethodRep createInstance(String name, String description, List<ParamRep> paramList) {
		MethodRep rep = createInstance(name, description);
		rep.setParamList(paramList);
		return rep;
	}

	public static MethodRep createInstance(String name, String description) {
		MethodRep rep = createInstance();
		rep.setName(name);
		rep.setDescription(description);
		return rep;
	}

	public static MethodRep createInstance() {
		MethodRep rep = new MethodRep();
		return rep;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<ParamRep> getParamList() {
		return paramList;
	}

	public void setParamList(List<ParamRep> paramList) {
		this.paramList = paramList;
	}


	@Override
	public MethodDoc getDocRepresentation() {
		return methodDefenition;
	}

	@Override
	public void setDocRepresentation(MethodDoc doc) {
		methodDefenition = doc;
	}


	public ClassRep getImpl() {
		return impl;
	}

	public void setImpl(ClassRep impl) {
		this.impl = impl;
	}
}
