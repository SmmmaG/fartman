package com.paragonsoftware.infocollector.doclet;

import com.paragonsoftware.infocollector.ImplemetationCollectorService;
import com.paragonsoftware.infocollector.impl.services.ImplementaionClassesCollectorService;
import com.paragonsoftware.infocollector.impl.services.InterfacesCollectorService;
import com.paragonsoftware.infocollector.representation.ClassRep;
import com.paragonsoftware.infocollector.representation.InterfaceRep;
import com.paragonsoftware.infocollector.representation.MethodRep;
import com.paragonsoftware.infocollector.representation.ParamRep;
import com.sun.javadoc.RootDoc;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Stack;

public class RestServicesInfoCollectorDoclet {

	public static final void start(RootDoc rootDoc) {
		final Collection<InterfaceRep> interfaces = new LinkedList<>();
		InterfacesCollectorService interfacesCollectorService = new InterfacesCollectorService();
		interfacesCollectorService.collect(interfaces, rootDoc);

		ImplemetationCollectorService implemetationCollectorService = new ImplementaionClassesCollectorService();
		final Collection<InterfaceRep> classes = new LinkedList<>();
		implemetationCollectorService.collect(classes, rootDoc);
		interfaces.forEach(interfaceRep -> {
			Stack<ClassRep> stack = new Stack<>();
			implemetationCollectorService.collectImplementation(stack, interfaceRep, classes);
			stack.forEach(classRep -> {
				interfaceRep.getMethods().stream().filter(methodRep -> methodRep.getImpl() == null).forEach(methodRep -> {
					boolean contains = false;
					for (MethodRep rep : classRep.getMethods()) {
						if (rep.getName().equals(methodRep.getName())) {
							if (rep.getParamList() != null && methodRep.getParamList() != null) {
								boolean all = rep.getParamList().size() == methodRep.getParamList().size();
								if (all) {
									for (int i = 0; i < rep.getParamList().size(); i++) {
										ParamRep repParam = rep.getParamList().get(i);
										ParamRep interfaceParam = methodRep.getParamList().get(i);
										if (repParam.getObjectReference().equals(interfaceParam.getObjectReference())) {
											all = false;
											break;
										}
									}
								}
								if (all) {
									contains = true;
									break;
								}
							} else if (rep.getParamList() == null && methodRep.getParamList() == null) {
								contains = true;
								break;
							}
						}
					}
					if (contains) {
						methodRep.setImpl(classRep);
					}
				});
			});
		});
		interfaces.forEach(interfaceRep -> {
			System.out.println(interfaceRep.toString());
		});
	}
}
